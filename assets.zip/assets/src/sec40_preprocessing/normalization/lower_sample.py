text = '｢初めての TensorFlow｣は定価2200円＋税です'
print(text.lower())
